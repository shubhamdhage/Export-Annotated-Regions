# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2018 Shubham Dhage dhageshubham75@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from __future__ import print_function

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('export_annotated_region')

from export_annotated_region_lib import Window
from export_annotated_region.AboutExportAnnotatedRegionDialog import AboutExportAnnotatedRegionDialog
from export_annotated_region.PreferencesExportAnnotatedRegionDialog import PreferencesExportAnnotatedRegionDialog




import cv2
import numpy as np
import os
from xml.dom import minidom
import matplotlib.path as mplPath
import numpy as np
import openslide
import cv2
import time


from multiprocessing import Process
import threading


# padd = 112
level = 0
openslide_formats = ['.ndpi', '.svs', '.tif', '.vms', '.vmu', '.scn', '.mrxs', '.tiff', 'svslide', 'bif']

def get_all_regions(file_name):
    mydoc = minidom.parse(file_name)
    annotations = mydoc.getElementsByTagName('Annotation')
    all_anns = []
    all_orgs = []
    all_paths = []
    for annotation in annotations:
        regions = annotation.getElementsByTagName('Region')
        all_regions = []
        orgs = []
        paths = []
        for region in regions:
            verticies = region.getElementsByTagName('Vertex')
            xy = []
            xy_path = []
            for item in verticies:
                xy.append(map(int,[item.getAttribute('X').encode('utf-8'),item.getAttribute('Y').encode('utf-8')]))
                xy_path.append([item.getAttribute('X'),item.getAttribute('Y')])
            all_regions.append(xy)
            ox,oy,wd,ht = cv2.boundingRect(np.asarray(xy))
            orgs.append([ox,oy,wd,ht])
            paths.append(mplPath.Path(xy_path))
        all_anns.append(all_regions)
        all_orgs.append(orgs)
        all_paths.append(paths)
    return all_anns,all_orgs,all_paths




def get_annotations_1(self,file_name,path,lrp1,level=0):
	ffl = len(self.format)
	ff = self.format
	padd = self.padd
    directory = self.directory + '/'
	all_anns,all_origins,all_paths = get_all_regions(file_name)
	if(str(ff) in openslide_formats):
		img = openslide.open_slide(path)
	else:
		img = cv2.imread(path)
	count = 0
	pathsplt = path.split('/')
	lwp1 = len(pathsplt)
	subfold_count = lrp1 - lwp1
    #print(pathsplt)
    #print(subfold_count)
	while(subfold_count < -1):
		if not os.path.exists(directory + pathsplt[subfold_count]):
		    os.mkdir(directory + pathsplt[subfold_count])
		directory = directory + pathsplt[subfold_count] + '/'
        subfold_count = subfold_count + 1

	for lyr in range(len(all_anns)):
	    all_regions = all_anns[lyr]
	    if not os.path.exists(directory + str(lyr)):
	        os.mkdir(directory + str(lyr))
	    if(len(all_regions) == 0):
	        continue
	    dir_path = directory + str(lyr) + '/'
	    origins = all_origins[lyr]
	    paths = all_paths[lyr]
	    nr = len(all_regions)
	    for tmp1 in range(nr):
	        if(len(origins[tmp1])==0):
	            print("Y")
	            continue
	        ox,oy,w,h = origins[tmp1]
	        region = all_regions[tmp1]
	        # mpl_path = paths[tmp1]
	        start_x = max(0 , ox - padd)
	        start_y = max(0 , oy - padd)
	        shifted_region = [[item[0] - start_x, item[1] - start_y] for item in region]
	        mask_im = np.zeros((h + 2*padd, w + 2*padd, 3))
	        mask_im = cv2.drawContours(mask_im, np.asarray([shifted_region]), -1, (255,255,255), -1, 8)
	        mask_im = np.array(mask_im, dtype=np.uint8)
            mask_im = cv2.cvtColor( mask_im, cv2.COLOR_BGR2GRAY)
            img_save_name = dir_path + 'im_' + str(count) + '_' + pathsplt[-1][0:-ffl] + '_layer_' + str(lyr) + '_' + str(ox) + '_' + str(oy) + '_' + str(w) + '_' + str(h)
	        if(ff in openslide_formats):
	        	im_object = img.read_region((start_x,start_y),level,(w + 2*padd, h + 2*padd))
	        	im_object.save(img_save_name + '_.png')
	        else:
	        	im_patch = img[start_y:start_y + h + 2*padd, start_x:start_x + w + 2*padd, :]
	        	cv2.imwrite(img_save_name + '_.png', im_patch)
	        cv2.imwrite(img_save_name + '_mask_.png', mask_im)
	        count = count + 1
	return count




# See export_annotated_region_lib.Window.py for more details about how this class works
class ExportAnnotatedRegionWindow(Window):
    __gtype_name__ = "ExportAnnotatedRegionWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(ExportAnnotatedRegionWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutExportAnnotatedRegionDialog
        self.PreferencesDialog = PreferencesExportAnnotatedRegionDialog

        # Code for other initialization actions should be added here 

        self.button_count = 0                     # Allows only one execution per click
		userhome = os.path.expanduser('~')
		self.directory = userhome + '/Desktop/Extracted_Regions'       # Default directory to the images
        # if not os.path.exists(self.directory):
        #     os.mkdir(self.directory)
        self.directory_control = 0    #  Controls which one to run launch_hardinfo_0  or  launch_hardinfo_1
        self.format = '.ndpi'         #  User selects the image format using drop down menu
        self.padd = 112               #  The padding used
        self.xml_toggle = True        # Check button


    def on_sourcefolder_file_set(self, widget):
        self.root_path = widget.get_filename()
        print("Source Folder Choosen: ", self.root_path)
        return self.root_path

    def on_xmlfolder_file_set(self, widget):
        self.xml_path = widget.get_filename()
        print("XML Folder Choosen: ", self.xml_path)
        return self.xml_path

    def on_storefolder_file_set(self, widget):
        self.directory = widget.get_filename()
        print("Store Folder Choosen: ", self.directory)
        return self.directory


    def on_checkbutton1_toggled(self, widget, data=None):
    	if(self.xml_toggle):
	        self.xml_path = self.root_path
	        self.ui.xmlfolder.set_sensitive(False)
	        self.directory_control = 1
	        self.xml_toggle = False
	    else:
	        self.xml_path = ''
	        self.ui.xmlfolder.set_sensitive(True)
	        self.directory_control = 0
	        self.xml_toggle = True

    def on_combobox1_changed(self, combo, data=None):
        tree_iter = combo.get_active_iter()
        if tree_iter is not None:
            model = combo.get_model()
            self.format = model[tree_iter][0]
            print("Selected: Image Format=%s" % self.format)
            # print(len(self.format))


    def on_entry1_activate(self,widget, data=None):
    	self.padd = int(widget.get_text())
    	print("Padding :", self.padd)


    def launch_hardinfo_0(self):
    	ffl = len(self.format)
        root_path = self.root_path + '/'
        xml_path = self.xml_path + '/'
        directory = self.directory + '/'
		if not os.path.exists(directory):
		    os.mkdir(directory)
        sub_fold = os.listdir(xml_path)
        print(sub_fold)
        n_fold = len(sub_fold)
        lt1 = root_path.split('/')
        lp1 = len(lt1) - 1
        for i_1 in range(n_fold):
            gdouble_fraction = float(i_1)/n_fold
            self.ui.progressbar1.set_fraction(gdouble_fraction)
            xml_file_name = xml_path + sub_fold[i_1]
            wsi = sub_fold[i_1][0:-4]
            print(wsi)
            for root,dirs,files in os.walk(root_path):
            	for fl in files:
            		if(fl[0:-ffl] == wsi):
            			wsi_path = root + '/' + fl
            c = get_annotations_1(self, xml_file_name, wsi_path, lp1)
        gdouble_fraction = float(i_1)/n_fold
        self.ui.progressbar1.set_fraction(1.0)
        self.button_count = self.button_count - 1
        return


    def launch_hardinfo_1(self):
        root_path = self.root_path
        xml_path = self.xml_path + '/'
        directory = self.directory + '/'
        ffl = len(self.format)
		if not os.path.exists(directory):
		    os.mkdir(directory)
        wsi_paths = []
        xml_files = []
        for root,dirs,files in os.walk(root_path):
        	found = 0
        	if(len(dirs) == 0):
        		lf = len(files)
        		if(lf != 0):
	        		for fl1 in files:
	        			for fl2 in files:
	        				if(fl1[0:-4] == fl2[0:-ffl]):
	        					if(fl1 != fl2 and (str(self.format) == str(fl2[-ffl:]))):
	        						wsi_paths.append(root + '/' + fl2)
	        						xml_files.append(root + '/' + fl1)
	        						break
	        			# 			found = 1
	        			# 			break
	        			# if(found == 1):
	        			# 	break
	    # print(wsi_paths)
	    # print(xml_files)
	    n_fold = len(xml_files)
        lt1 = root_path.split('/')
        lp1 = len(lt1)
        for i_1 in range(n_fold):
            gdouble_fraction = float(i_1)/n_fold
            self.ui.progressbar1.set_fraction(gdouble_fraction)
	    	c = get_annotations_1(self, xml_files[i_1], wsi_paths[i_1], lp1)
        self.ui.progressbar1.set_fraction(1.0)
        self.button_count = self.button_count - 1
        return


    def on_button1_clicked(self, widget, data=None):
        # print(self.button_count)
        if(self.button_count == 0):
            self.button_count = self.button_count + 1
            if(self.directory_control == 0):
	            t1 = threading.Thread(target=self.launch_hardinfo_0)
	            t1.daemon = True
	            t1.start()
	        else:
	            t1 = threading.Thread(target=self.launch_hardinfo_1)
	            t1.daemon = True
	            t1.start()	        	

            # t1.join()


